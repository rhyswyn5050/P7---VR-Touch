﻿using UnityEngine;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System;
using System.Text;

using System.Linq;


public delegate void ActivityEventHandlerUDP(string msg);

public class UDPUDPUDP : MonoBehaviour
{
    private System.Threading.Thread ActivityListenerThread;
    private bool run = true;
    public event ActivityEventHandlerUDP activityData;

    private int receivePortUDP = 5005; //UDP Port
    private UdpClient client;
    private IPEndPoint remoteIpEndPoint;

    public string myMessage = "";

    string[] strArr = new string[] { "0", "0", "0", "0", "0" ,"0","0", "0"};
    float[] fArr = new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};

    //Set the box dimentions
    float caseHight = 200;  //From QR code 1 to 6
    float caseLength = 120; //From QR Code 2 to 4
    float caseWidth = 120;  //From QR code 3 to 5

    public GameObject MyObject;

    void Start()
    {
        Debug.Log("Start Activity remote listener");

        //Create UDP client
        client = new System.Net.Sockets.UdpClient(receivePortUDP);

        //Create UDP end point for any ip address at the specified port
        remoteIpEndPoint = new System.Net.IPEndPoint(System.Net.IPAddress.Any, receivePortUDP);

        //Create and start the UDP listner thread
        ActivityListenerThread = new System.Threading.Thread(new System.Threading.ThreadStart(listenActivityUDPThread));
        ActivityListenerThread.Name = "Activity UDP listen thread";
        ActivityListenerThread.Start();

    }


    void OnDestroy()
    {
        run = false;
        if (ActivityListenerThread != null) ActivityListenerThread.Abort();
        if (client != null) client.Close();
    }


    private void listenActivityUDPThread()
    {
        while (run)
        {

            try
            {
                //Read the bottle
                byte[] packet = client.Receive(ref remoteIpEndPoint);
                // send message //
                if (packet != null && packet.Length > 0)
                {
                    string message = ExtractString(packet, 0, packet.Length);
                    Debug.Log(message);
                    myMessage = message;
                    if (activityData != null)
                    {
                        activityData(message);
                    }

                }
                Debug.Log(myMessage);
            }
            catch (Exception e)
            {
                Debug.Log(e.ToString());
            }
        }
    }

    private string ExtractString(byte[] packet, int start, int length)
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < packet.Length; i++)
        {
            sb.Append((char)packet[i]);
        }
        return sb.ToString();
    }

    void ReadData(UdpClient ci, String text)
    {
        Console.WriteLine("Received text message: " + text);
    }

    void Update()
    {
        //Seperate string recived via the UDP stream into a string array
        strArr = myMessage.Split(',');

        //Convert the string array into a float array
        for (int i = 0; i < strArr.Length; i++)
        {
            Debug.Log(strArr[i]);
            decimal value = 0;
            decimal.TryParse(strArr[i], out value);
            fArr[i] = (float)value;
        }

        //Set the position and orientation

        //Y and Z axis are inverted
        MyObject.transform.position = new Vector3(fArr[0], -fArr[1], -fArr[2]);
        //Object is rotated 180 degrees around Z
        MyObject.transform.rotation = Quaternion.AngleAxis(-fArr[5] + 180, Vector3.forward);
        MyObject.transform.rotation *= Quaternion.AngleAxis(fArr[4], Vector3.up);
        MyObject.transform.rotation *= Quaternion.AngleAxis(-fArr[3], Vector3.right);

        //Depending on the QR code the object is rotated accordingly
        int caseSwitch = (int)fArr[6];

        if((int)fArr[7] == 3)
        {
            //Set the box dimentions
            caseHight = 69;  //From QR code 1 to 6
            caseLength = 69; //From QR Code 2 to 4
            caseWidth = 69;  //From QR code 3 to 5
        }

        switch (caseSwitch)
        {
            case 1:
                Vector3 offset1 = MyObject.transform.forward * (caseHight / 2);
                MyObject.transform.position = MyObject.transform.position + offset1;
                MyObject.transform.rotation *= Quaternion.AngleAxis(-90, Vector3.right);
                MyObject.transform.rotation *= Quaternion.AngleAxis(-90, Vector3.up);
                break;
            case 2:
                Vector3 offset2 = MyObject.transform.forward * (caseLength / 2);
                MyObject.transform.position = MyObject.transform.position + offset2;
                MyObject.transform.rotation *= Quaternion.AngleAxis(-90, Vector3.up);
                break;
            case 3:
                Vector3 offset3 = MyObject.transform.forward * (caseWidth / 2);
                MyObject.transform.position = MyObject.transform.position + offset3;
                MyObject.transform.rotation *= Quaternion.AngleAxis(180, Vector3.up);
                break; 
            case 4:
                Vector3 offset4 = MyObject.transform.forward * (caseLength / 2);
                MyObject.transform.position = MyObject.transform.position + offset4;
                MyObject.transform.rotation *= Quaternion.AngleAxis(90, Vector3.up);
                break;
            case 5:
                Vector3 offset5 = MyObject.transform.forward * (caseWidth / 2);
                MyObject.transform.position = MyObject.transform.position + offset5;
                break;
            case 6:
                Vector3 offset6 = MyObject.transform.forward * (caseHight / 2);
                MyObject.transform.position = MyObject.transform.position + offset6;
                MyObject.transform.rotation *= Quaternion.AngleAxis(90, Vector3.right);
                MyObject.transform.rotation *= Quaternion.AngleAxis(-90, Vector3.up);
                break;
            case 7:
                break;
        }
    }
}
 